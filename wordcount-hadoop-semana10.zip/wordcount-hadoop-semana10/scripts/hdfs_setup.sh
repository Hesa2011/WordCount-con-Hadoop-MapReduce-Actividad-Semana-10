#!/bin/bash
# hdfs_setup.sh
# --------------
# Comandos para preparar el entorno en HDFS antes de correr el job.
# Pensado para ejecutarse en el nodo maestro del cluster (local o en VM/nube).

set -e

HDFS_BASE=/user/hesa/wordcount
LOCAL_DATASET=./dataset

echo ">> 1. Creando estructura de directorios en HDFS"
hdfs dfs -mkdir -p ${HDFS_BASE}/input

echo ">> 2. Subiendo los documentos de texto locales a HDFS"
hdfs dfs -put -f ${LOCAL_DATASET}/*.txt ${HDFS_BASE}/input/

echo ">> 3. Verificando archivos subidos"
hdfs dfs -ls ${HDFS_BASE}/input/

echo ">> Listo. El directorio de entrada es: ${HDFS_BASE}/input"
echo ">> El directorio de salida NO debe existir antes de correr el job, ej: ${HDFS_BASE}/output_r1"
