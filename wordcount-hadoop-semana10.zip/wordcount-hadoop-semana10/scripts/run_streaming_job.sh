#!/bin/bash
# run_streaming_job.sh
# ---------------------
# Script "Driver" para lanzar el job de WordCount usando Hadoop Streaming
# (en lugar de un Driver Java, Hadoop Streaming permite usar cualquier
# lenguaje que lea de stdin y escriba a stdout como Mapper/Reducer).
#
# Uso:
#   ./run_streaming_job.sh <input_hdfs> <output_hdfs> <num_reducers>
#
# Ejemplo:
#   ./run_streaming_job.sh /user/hesa/wordcount/input /user/hesa/wordcount/output 2

set -e

INPUT_DIR=${1:-/user/hesa/wordcount/input}
OUTPUT_DIR=${2:-/user/hesa/wordcount/output}
NUM_REDUCERS=${3:-1}

# Ruta al JAR de streaming que trae toda distribucion de Hadoop.
STREAMING_JAR=$(find "${HADOOP_HOME}" -name "hadoop-streaming*.jar" | head -n 1)

echo "=== Lanzando job Hadoop Streaming ==="
echo "Input:      ${INPUT_DIR}"
echo "Output:     ${OUTPUT_DIR}"
echo "Reducers:   ${NUM_REDUCERS}"
echo "======================================"

hadoop jar "${STREAMING_JAR}" \
    -D mapreduce.job.reduces="${NUM_REDUCERS}" \
    -files streaming/mapper.py,streaming/reducer.py \
    -mapper "python3 mapper.py" \
    -combiner "python3 reducer.py" \
    -reducer "python3 reducer.py" \
    -input "${INPUT_DIR}" \
    -output "${OUTPUT_DIR}"

echo "=== Job finalizado. Resultado en HDFS: ${OUTPUT_DIR} ==="
