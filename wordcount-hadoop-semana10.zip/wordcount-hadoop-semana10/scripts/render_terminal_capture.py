#!/usr/bin/env python3
"""Genera una imagen tipo 'captura de terminal' a partir de texto plano,
para usar como evidencia visual de ejecucion en el informe."""

import sys
from PIL import Image, ImageDraw, ImageFont

FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
]


def render(text_path, out_path, title="terminal"):
    with open(text_path, "r", encoding="utf-8") as f:
        raw_lines = f.read().splitlines()

    # Expandimos tabs a espacios alineados (evita glifos "caja" faltantes)
    # y detectamos si la linea es un par clave-valor para colorearla distinto.
    lines = []
    for line in raw_lines:
        is_kv = "\t" in line and not line.startswith("$")
        expanded = line.expandtabs(4)
        lines.append((expanded, is_kv))

    font_size = 16
    try:
        font = ImageFont.truetype(FONT_PATHS[0], font_size)
    except Exception:
        font = ImageFont.load_default()

    line_height = font_size + 8
    padding = 24
    title_bar_h = 34

    # Ancho dinamico segun la linea mas larga
    tmp_img = Image.new("RGB", (10, 10))
    tmp_draw = ImageDraw.Draw(tmp_img)
    max_w = 0
    for text, _ in lines:
        bbox = tmp_draw.textbbox((0, 0), text, font=font)
        max_w = max(max_w, bbox[2] - bbox[0])
    width = max(700, max_w + padding * 2 + 20)
    height = title_bar_h + padding * 2 + line_height * len(lines)

    img = Image.new("RGB", (width, height), "#1e1e1e")
    draw = ImageDraw.Draw(img)

    # Barra de titulo estilo macOS/Linux terminal
    draw.rectangle([0, 0, width, title_bar_h], fill="#323233")
    for i, color in enumerate(["#ff5f56", "#ffbd2e", "#27c93f"]):
        draw.ellipse([14 + i * 22, 11, 26 + i * 22, 23], fill=color)
    tb = draw.textbbox((0, 0), title, font=font)
    draw.text((width / 2 - (tb[2] - tb[0]) / 2, 8), title, fill="#cccccc", font=font)

    y = title_bar_h + padding
    for text, is_kv in lines:
        color = "#d4d4d4"
        if text.startswith("$"):
            color = "#6fd67c"
        elif is_kv:
            color = "#9cdcfe"
        draw.text((padding, y), text, fill=color, font=font)
        y += line_height

    img.save(out_path)
    print(f"Guardado: {out_path}")


if __name__ == "__main__":
    render(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "terminal")
