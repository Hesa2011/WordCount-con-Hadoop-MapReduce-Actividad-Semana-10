#!/usr/bin/env python3
"""
simulate_reducers.py
----------------------
Simula localmente el comportamiento de Hadoop al variar el numero de
tareas Reduce (1, 2, 4), replicando la logica real del Partitioner por
defecto de Hadoop (HashPartitioner): partition = hash(key) % numReducers.

Esto permite, sin un cluster real, observar:
  - Que cada reducer recibe un subconjunto disjunto de claves (particionado).
  - Como se distribuye la carga de palabras entre reducers.
  - Tiempos de ejecucion aproximados para cada configuracion.

Nota metodologica (incluida tambien en el informe): en un cluster real con
multiples nodos fisicos, mas reducers generalmente reducen el tiempo total
porque se ejecutan en PARALELO en distintas maquinas. En esta simulacion
de un solo proceso, se muestra el particionamiento real y se ejecutan los
reducers de forma concurrente con multiprocessing para reflejar el paralelismo.
"""

import subprocess
import sys
import time
from multiprocessing import Pool
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
MAPPER = BASE / "streaming" / "mapper.py"
DATASET = BASE / "dataset"
OUTPUT_DIR = BASE / "output"


def run_mapper():
    """Ejecuta el mapper sobre todo el dataset y devuelve la lista de pares (palabra, 1).

    Implementado en Python puro (sin invocar 'bash -c cat ...') para que
    funcione igual en Windows, macOS y Linux.
    """
    all_text = []
    for txt_file in sorted(DATASET.glob("*.txt")):
        all_text.append(txt_file.read_text(encoding="utf-8"))
    combined_text = "\n".join(all_text)

    map_proc = subprocess.run(
        [sys.executable, str(MAPPER)],
        input=combined_text,
        capture_output=True,
        text=True,
    )
    pairs = []
    for line in map_proc.stdout.splitlines():
        word, count = line.split("\t")
        pairs.append((word, int(count)))
    return pairs


def partition(pairs, num_reducers):
    """Replica el HashPartitioner de Hadoop: partition = hash(key) % numReducers."""
    buckets = [[] for _ in range(num_reducers)]
    for word, count in pairs:
        idx = (hash(word) & 0x7FFFFFFF) % num_reducers
        buckets[idx].append((word, count))
    return buckets


def reduce_bucket(bucket):
    """Agrega (suma) los valores de un bucket, tal como haria una tarea Reduce."""
    totals = {}
    for word, count in bucket:
        totals[word] = totals.get(word, 0) + count
    return totals


def run_for_n_reducers(n):
    pairs = run_mapper()
    buckets = partition(pairs, n)

    start = time.perf_counter()
    # multiprocessing.Pool ejecuta cada reducer en un proceso separado,
    # emulando el paralelismo real entre tareas Reduce en distintos nodos.
    with Pool(processes=n) as pool:
        results = pool.map(reduce_bucket, buckets)
    elapsed = time.perf_counter() - start

    merged = {}
    for r in results:
        merged.update(r)

    sizes = [len(b) for b in buckets]
    return elapsed, sizes, merged


def main():
    print(f"{'Reducers':<10}{'Tiempo (s)':<14}{'Palabras/reducer (particionado)'}")
    print("-" * 70)

    for n in (1, 2, 4):
        elapsed, sizes, merged = run_for_n_reducers(n)
        print(f"{n:<10}{elapsed:<14.4f}{sizes}")

        out_file = OUTPUT_DIR / f"wordcount_r{n}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            for word in sorted(merged):
                f.write(f"{word}\t{merged[word]}\n")

    print("\nResultados guardados en output/wordcount_r1.txt, wordcount_r2.txt, wordcount_r4.txt")


if __name__ == "__main__":
    main()
