#!/bin/bash
# build_and_run_java.sh
# -----------------------
# Compila el proyecto Java y ejecuta el job para un numero dado de reducers,
# midiendo el tiempo total de ejecucion (usado en el analisis de rendimiento).
#
# Uso:
#   ./build_and_run_java.sh <num_reducers>

set -e

NUM_REDUCERS=${1:-1}
HDFS_BASE=/user/hesa/wordcount
OUTPUT_DIR=${HDFS_BASE}/output_r${NUM_REDUCERS}

echo ">> Compilando el proyecto con Maven"
mvn -q clean package

echo ">> Eliminando salida previa en HDFS (si existe)"
hdfs dfs -rm -r -f ${OUTPUT_DIR}

echo ">> Ejecutando job con ${NUM_REDUCERS} reducer(s)"
START=$(date +%s)

hadoop jar target/wordcount-hadoop-1.0.jar com.hesa.wordcount.WordCountDriver \
    ${HDFS_BASE}/input \
    ${OUTPUT_DIR} \
    ${NUM_REDUCERS}

END=$(date +%s)
echo ">> Tiempo total de ejecucion: $((END - START)) segundos"

echo ">> Recuperando resultado desde HDFS"
hdfs dfs -ls ${OUTPUT_DIR}
hdfs dfs -cat ${OUTPUT_DIR}/part-r-* | sort -k2,2 -nr | head -n 20
