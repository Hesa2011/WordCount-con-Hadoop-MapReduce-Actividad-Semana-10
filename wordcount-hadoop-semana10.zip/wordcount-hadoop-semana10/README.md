# WordCount con Hadoop MapReduce — Actividad Semana 10

Implementación de un job **MapReduce** clásico (conteo de palabras) sobre un
conjunto de documentos de texto, desarrollado en dos variantes:

1. **Java** — API nativa de Hadoop (`org.apache.hadoop.mapreduce`).
2. **Python (Hadoop Streaming)** — `mapper.py` / `reducer.py` ejecutables vía `hadoop-streaming.jar`.

Materia: Programación Paralela y Distribuida.
Autora: Healy Santos HESA2011.

## Estructura del repositorio

```
wordcount-hadoop/
├── README.md
├── pom.xml                          # Build Maven para la versión Java
├── src/main/java/com/hesa/wordcount/
│   ├── WordCountMapper.java         # Fase Map
│   ├── WordCountReducer.java        # Fase Reduce (y también Combiner)
│   └── WordCountDriver.java         # Configura y lanza el Job
├── streaming/
│   ├── mapper.py                    # Fase Map (Hadoop Streaming)
│   └── reducer.py                   # Fase Reduce (Hadoop Streaming)
├── dataset/
│   ├── doc1_sistemas_distribuidos.txt
│   ├── doc2_bigdata_conceptos.txt
│   └── doc3_flujo_mapreduce.txt
├── scripts/
│   ├── hdfs_setup.sh                # Crea directorio en HDFS y sube el dataset
│   ├── build_and_run_java.sh        # Compila y ejecuta la versión Java
│   ├── run_streaming_job.sh         # Ejecuta la versión Python Streaming
│   ├── simulate_reducers.py         # Compara 1, 2 y 4 reducers (particionado + tiempos)
│   └── render_terminal_capture.py   # Utilidad para generar capturas de terminal
├── output/                          # Resultados generados localmente
└── docs/                            # Capturas de ejecución usadas en el informe
```

## 1. Preparación del entorno

Este proyecto se probó en dos modalidades:

- **Clúster Hadoop real** (pseudo-distribuido en una VM o distribución como
  Cloudera/Hortonworks/Hadoop 3.3.6 standalone): usar los scripts `scripts/hdfs_setup.sh`,
  `scripts/build_and_run_java.sh` y `scripts/run_streaming_job.sh` tal cual.
- **Emulación local del pipeline** (usada para generar los resultados y capturas
  incluidos en este repositorio, dado que el entorno de desarrollo no cuenta con
  un clúster Hadoop instalado): se reproduce el flujo Map → Shuffle(sort) → Reduce
  con el pipeline estándar de Unix, que es exactamente el mecanismo interno que usa
  Hadoop Streaming:

  ```bash
  cat dataset/*.txt | python3 streaming/mapper.py | sort | python3 streaming/reducer.py
  ```

### Nota para Windows / PowerShell

Los comandos de arriba usan sintaxis de Unix. En **PowerShell** (no Git Bash ni WSL):

- `cat` y `sort` (sin argumentos) SÍ funcionan igual, porque PowerShell los alias a
  `Get-Content` y `Sort-Object`.
- `sort -k2,2 -nr` y `head -n 15` (flags de Unix) **no funcionan** en PowerShell.
  Usa en su lugar:

  ```powershell
  Import-Csv output/wordcount_full.txt -Delimiter "`t" -Header Palabra,Conteo |
    Sort-Object {[int]$_.Conteo} -Descending |
    Select-Object -First 15
  ```

- `scripts/simulate_reducers.py` funciona igual en Windows, macOS y Linux sin
  necesidad de Git Bash ni WSL (usa Python puro, sin invocar `bash`/`cat` del sistema).
- Para más comodidad, se recomienda instalar la extensión **WSL** o **Git Bash**
  en VS Code, lo que permite correr exactamente los mismos comandos que en Linux/macOS.



## 2. Cargar el dataset a HDFS (clúster real)

```bash
hdfs dfs -mkdir -p /user/hesa/wordcount/input
hdfs dfs -put -f dataset/*.txt /user/hesa/wordcount/input/
hdfs dfs -ls /user/hesa/wordcount/input/
```

O simplemente: `./scripts/hdfs_setup.sh`

## 3. Ejecutar el job

### Versión Java

```bash
mvn clean package
hadoop jar target/wordcount-hadoop-1.0.jar com.hesa.wordcount.WordCountDriver \
    /user/hesa/wordcount/input \
    /user/hesa/wordcount/output \
    2   # número de reducers
```

O: `./scripts/build_and_run_java.sh 2`

### Versión Python (Hadoop Streaming)

```bash
./scripts/run_streaming_job.sh /user/hesa/wordcount/input /user/hesa/wordcount/output 2
```

## 4. Recuperar resultados desde HDFS

```bash
hdfs dfs -ls /user/hesa/wordcount/output
hdfs dfs -cat /user/hesa/wordcount/output/part-r-* | sort -k2,2 -nr | head -n 20
```

## 5. Análisis de rendimiento (1, 2, 4 reducers)

```bash
python3 scripts/simulate_reducers.py
```

Resultado obtenido sobre el dataset de 3 documentos (747 palabras totales, 308 únicas):

| Reducers | Tiempo (s) | Partición de claves por reducer |
|---|---|---|
| 1 | 0.0392 | [747] |
| 2 | 0.0130 | [312, 435] |
| 4 | 0.0461 | [158, 238, 154, 197] |

Ver el informe (`informe_semana10.docx`) para el análisis detallado.

## Licencia / uso académico

Proyecto desarrollado con fines educativos para la Actividad Semana 10 de la materia.
