#!/usr/bin/env python3

import sys
import re

TOKEN_PATTERN = re.compile(r"[a-z0-9áéíóúñ]+")


def main():

    for line in sys.stdin:
        line = line.strip().lower()
        if not line:
            continue

        words = TOKEN_PATTERN.findall(line)

        for word in words:

            print(f"{word}\t1")


if __name__ == "__main__":
    main()
